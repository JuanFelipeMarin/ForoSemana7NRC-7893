package com.example.forosemana7nrc_7893

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.forosemana7nrc_7893.ui.theme.ForoSemana7NRC7893Theme
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.sqrt
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch


class MainActivity : ComponentActivity(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private var stepCount by mutableStateOf(0)
    private var lastMagnitude = 0f
    private var lastStepTimestamp = 0L
    private val stepThreshold = 6f
    private lateinit var stepDataStore: StepDataStore
    private var lastRecordedDate: String = ""

    private val stepHistory = mutableStateMapOf<String, Int>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inicializa StepDataStore
        stepDataStore = StepDataStore(this)

        // Configura el sensor
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI)

        // Cargar historial almacenado al iniciar
        lifecycleScope.launchWhenStarted {
            stepDataStore.stepHistoryFlow.collect { savedHistory ->
                stepHistory.putAll(savedHistory)

                // Detectar cuál es el último día almacenado
                lastRecordedDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

                // Restaurar contador si ese día ya tiene valor
                stepCount = stepHistory[lastRecordedDate] ?: 0
            }
        }

        // Interfaz
        setContent {
            ForoSemana7NRC7893Theme {
                Scaffold(
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    StepCounterUI(
                        currentSteps = stepCount,
                        history = stepHistory,
                        modifier = Modifier.padding(innerPadding),
                        onResetToday = { resetTodaySteps() }
                    )
                }
            }
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        event?.let {
            val x = it.values[0]
            val y = it.values[1]
            val z = it.values[2]

            val magnitude = sqrt(x * x + y * y + z * z)
            val delta = kotlin.math.abs(magnitude - lastMagnitude)
            lastMagnitude = magnitude

            println("Delta detectado: $delta")

            if (delta > 6f) {
                stepCount++
                updateDailySteps()
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun updateDailySteps() {
        val currentDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

        if (currentDate != lastRecordedDate) {
            stepCount = 0
            lastRecordedDate = currentDate
        }

        stepHistory[currentDate] = stepCount

        lifecycleScope.launch {
            stepDataStore.saveStepHistory(stepHistory)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        sensorManager.unregisterListener(this)
    }

    private fun resetTodaySteps() {
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        stepCount = 0
        stepHistory[today] = 0

        lifecycleScope.launch {
            stepDataStore.saveStepHistory(stepHistory)
        }
    }

}

@Composable
fun StepCounterUI(currentSteps: Int, history: Map<String, Int>, modifier: Modifier = Modifier, onResetToday: () -> Unit) {
    Column(
        modifier = modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(text = "Contador de pasos", style = MaterialTheme.typography.headlineMedium)
        Text(text = "Pasos actuales: $currentSteps", style = MaterialTheme.typography.bodyLarge)

        Button(onClick = onResetToday) {
            Text("Reiniciar pasos de hoy")
        }

        Divider()

        Text(text = "Historial diario:", style = MaterialTheme.typography.headlineSmall)

        history.entries.forEach { (date, steps) ->
            Text("$date : $steps pasos", style = MaterialTheme.typography.bodyMedium)
        }

        Spacer(modifier = Modifier.height(24.dp))

        if (history.isNotEmpty()) {
            Text(text = "Gráfico de pasos", style = MaterialTheme.typography.titleMedium)

            SimpleBarChart(history = history)
        }
    }
}

@Composable
fun SimpleBarChart(history: Map<String, Int>, modifier: Modifier = Modifier) {
    if (history.isEmpty()) return

    val maxSteps = (history.values.maxOrNull() ?: 1).toFloat()
    val barWidth = 80f
    val spacing = 30f

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(220.dp)
    ) {
        val canvasWidth = size.width
        val canvasHeight = size.height

        var xPosition = spacing

        history.entries.forEach { (date, steps) ->
            val barHeight = (steps / maxSteps) * canvasHeight

            drawRect(
                color = Color.Blue,
                topLeft = Offset(xPosition, canvasHeight - barHeight),
                size = androidx.compose.ui.geometry.Size(barWidth, barHeight)
            )

            xPosition += barWidth + spacing
        }
    }
}