package com.example.forosemana7nrc_7893

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

// Extension para inicializar datastore
val Context.dataStore by preferencesDataStore("step_history")

class StepDataStore(private val context: Context) {

    companion object {
        val STEP_HISTORY_KEY = stringSetPreferencesKey("step_history")
    }

    // Leer historial de pasos
    val stepHistoryFlow: Flow<Map<String, Int>> = context.dataStore.data
        .map { preferences ->
            preferences[STEP_HISTORY_KEY]?.associate { entry ->
                val (date, steps) = entry.split(":")
                date to steps.toInt()
            } ?: emptyMap()
        }

    // Guardar historial actualizado
    suspend fun saveStepHistory(history: Map<String, Int>) {
        context.dataStore.edit { preferences ->
            preferences[STEP_HISTORY_KEY] = history.map { (date, steps) -> "$date:$steps" }.toSet()
        }
    }
}
